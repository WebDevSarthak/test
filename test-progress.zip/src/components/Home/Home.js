import React from 'react'
import Preloader from './Preloader/Preloader'
import Header from './Header/Header'
import HomeArea from './HomeArea/HomeArea'
import ContactArea from './ContactArea/ContactArea'
import TownPlanning from './TownPlanning/TownPlanning'
import NewsArea from './NewsArea/NewsArea'
import Project from './Project/Project'
import WorkArea from './WorkArea/WorkArea'
import Service from './Service/Service'
import PeopleArea from './PeopleArea/PeopleArea'
import SupportArea from './SupportArea/SupportArea'
import PracticeArea from './PracticeArea/PracticeArea' 


function Home(){
    return(
        <div>
            <Preloader />
            <Header />
            <HomeArea />
            <ContactArea />
            <TownPlanning />
            <NewsArea />
            <Project />
            <WorkArea />
            <Service />
            <PeopleArea />
            <SupportArea />
            <PracticeArea />
        </div>   
    )
}

export default Home