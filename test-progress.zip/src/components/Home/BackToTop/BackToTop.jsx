import React from 'react'

function BackToTop(){
    return(
        <div>
            <a href="#" class="back-to-top"><i class="fal fa-angle-up"></i></a>
        </div>
    )

}

export default BackToTop