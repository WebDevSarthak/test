import React from 'react'
import '../../Global.css'
import '../BackToTop/BackToTop.css'

function BackToTop(){
    return(
        <div>
            <a href="#" className="back-to-top"><i class="fal fa-angle-up"></i></a>
        </div>
    )

}

export default BackToTop