import React from 'react'
import ImgFour from '../../../assets/img/img4.jpg'
import ImgFive  from '../../../assets/img/img5.jpg'
import ImgSix from '../../../assets/img/img6.jpg'
import ImgSeven from '../../../assets/img/img7.jpg'
// img/img4.jpg
// 567

function Project(){
    return(
        <div>
            <div class="project_area section_padd">
                <div class="container container_lg">
                    <div class="row">
                        <div class="col-lg-4 mt_30">
                            <h2 class="title">our projects</h2>
                            <h4 class="mt_30">Town Planners and Project Managers</h4>
                        </div>
                        <div class="col-lg-8 mt_30">
                            <div class="content">
                                <p class="mt_20">With hundreds of projects completed in our two decades of our town planning consultancy, more than 98% of our clients' developments have been successful. We are proud to be one of the most effective town planning agencies in New South Wales with a reputation for professionalism and success.</p>
                                <div class="title w-100"></div>
                                <div class="row">
                                    <div class="col-md-6 mt_30">
                                        <a href="/#" class="box" style={{backgroundImage: `url(${ImgFour})`}}>
                                            <div class="category">Strategic Planning</div>
                                            <div class="box_content">
                                                <div>
                                                    <div class="d-flex align-items-center date">
                                                        <i class="fas fa-calendar-alt"></i>
                                                        May 7, 2020
                                                    </div>
                                                    <h4>Business Park</h4>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-6 mt_30">
                                        <a href="/#" class="box" style={{backgroundImage: `url(${ImgFive})`}}>
                                            <div class="category">Project Management</div>
                                            <div class="box_content">
                                                <div>
                                                    <div class="d-flex align-items-center date">
                                                        <i class="fas fa-calendar-alt"></i>
                                                        May 7, 2020
                                                    </div>
                                                    <h4>Residential Project Management</h4>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-6 mt_30">
                                        <a href="/#" class="box" style={{backgroundImage: `url(${ImgSix})`}}>
                                            <div class="category">Masterplanning</div>
                                            <div class="box_content">
                                                <div>
                                                    <div class="d-flex align-items-center date">
                                                        <i class="fas fa-calendar-alt"></i>
                                                        May 7, 2020
                                                    </div>
                                                    <h4>Masterplanning</h4>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-6 mt_30">
                                        <a href="/#" class="box" style={{backgroundImage: `url(${ImgSeven})`}}>
                                            <div class="category">Rezoning</div>
                                            <div class="box_content">
                                                <div>
                                                    <div class="d-flex align-items-center date">
                                                        <i class="fas fa-calendar-alt"></i>
                                                        May 7, 2020
                                                    </div>
                                                    <h4>Residential Rezoning</h4>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    )
}

export default Project